package com.freader.bookmodel;

public interface PagedBookListener {
	public void callback(PagedBook pb);
}
